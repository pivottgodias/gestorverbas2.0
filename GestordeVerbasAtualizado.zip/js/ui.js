
class UI {
    static clearItemFields(button) {
        const itemRow = button.closest('.item-row');
        if (itemRow) {
            const inputs = itemRow.querySelectorAll('input');
            inputs.forEach(input => input.value = '');
        }
    }

    static updateSummary() {
        // função existente
    }
}
