
function createSellInItem(produto, quantidade, valorUnitario) {
    return `
    <div class="item-row" style="position: relative;">
        <button type="button" class="clear-item-btn" onclick="UI.clearItemFields(this)">
            <i class="fas fa-rotate-right"></i>
        </button>
        <input type="text" class="produto" value="${produto}" placeholder="Produto">
        <input type="number" class="quantidade" value="${quantidade}" placeholder="Quantidade">
        <input type="number" class="valor-unitario" value="${valorUnitario}" placeholder="Valor Unitário">
    </div>`;
}

function createSellOutItem(produto, quantidade, valorUnitario) {
    return `
    <div class="item-row" style="position: relative;">
        <button type="button" class="clear-item-btn" onclick="UI.clearItemFields(this)">
            <i class="fas fa-rotate-right"></i>
        </button>
        <input type="text" class="produto" value="${produto}" placeholder="Produto">
        <input type="number" class="quantidade" value="${quantidade}" placeholder="Quantidade">
        <input type="number" class="valor-unitario" value="${valorUnitario}" placeholder="Valor Unitário">
    </div>`;
}

function createMerchItem(descricao, valor) {
    return `
    <div class="item-row" style="position: relative;">
        <button type="button" class="clear-item-btn" onclick="UI.clearItemFields(this)">
            <i class="fas fa-rotate-right"></i>
        </button>
        <input type="text" class="descricao" value="${descricao}" placeholder="Descrição">
        <input type="number" class="valor" value="${valor}" placeholder="Valor">
    </div>`;
}
